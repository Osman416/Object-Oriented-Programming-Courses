﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1202S15As2_Osman
{
    class Airport
    {
        public Airport()
        {

        }
    }
}
