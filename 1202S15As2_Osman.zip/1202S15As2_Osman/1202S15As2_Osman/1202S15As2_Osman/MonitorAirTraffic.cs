﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1202S15As2_Osman
{
    public class MonitorAirTraffic
    {
        public static void Main()
        {
            //int counter = 1;
            //int i = 1;
            //int exit_value;
            int user_selection;
            string[] airport_name = new string[3];
            string[] airport_city = new string[3];
            double[] arrival_RunWay_Charges = new double[3];
            double[] departure_RunWay_Charges = new double[3];
            string[] activity_date = new string[3];
            int[] total_passengers = new int[3];
            double[] revenue_thatday = new double[3];
            Console.Clear(); //Console.BackgroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine(); Console.WriteLine(); Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("         Airport Monitoring Application");
            Console.WriteLine(); Console.WriteLine(); Console.WriteLine();
            Console.WriteLine("       Enter 1 to Enter New Airport Data"); Console.WriteLine();
            Console.WriteLine("       Enter 2 to Print Airport Data Report"); Console.WriteLine();
            Console.WriteLine("       Enter 3 to EXIT the Application");
            Console.WriteLine();
            user_selection = Convert.ToInt16(Console.ReadLine());
            if ((user_selection < 1) || (user_selection > 3))
            {
                Console.ForegroundColor = ConsoleColor.Red; 
                Console.WriteLine("You did not enter value between 1 to 3   " + "Enter Valid Integer");
                //MessageBox.Show(user_selection, "Enter Values between 1 to 3  ", MessageBoxButtons.OK);
                user_selection = Convert.ToInt16(Console.ReadLine());
            }
            while (Convert.ToInt16(user_selection) == 1)
            {

                Console.WriteLine(); Console.WriteLine();
                for (int i = 1; 1 < 4; i++)
                {
                    Console.Write("Enter Airport Name:"); airport_name[i] = Console.ReadLine();
                    Console.Write("Enter Airport City:"); airport_city[i] = Console.ReadLine();
                    Console.Write("Enter Arrival Charges:"); arrival_RunWay_Charges[i] = Convert.ToDouble(Console.ReadLine());
                    Console.Write("Enter Departure Charges:"); departure_RunWay_Charges[i] = Convert.ToDouble(Console.ReadLine());
                    Console.Write("Enter Activity Date:"); activity_date[i] = Console.ReadLine();
                    Console.Write("Enter Total Passengers of the day:"); total_passengers[i] = Convert.ToInt16(Console.ReadLine());
                    Console.Write("Enter Revenue for the Day:"); revenue_thatday[i] = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine();
                    //Console.Write("\nEnter 3 to exit or press ENTER key to continue\n"); 
                    //user_selection = Convert.ToInt32(Console.ReadLine());
                    //Console.WriteLine();
                    if (user_selection == 3)
                    {
                        //user_selection = Convert.ToInt16(Console.ReadLine()); Return;
                        //return;  Environment.Exit(0);
                    }
                    
                }
            }
            if (Convert.ToInt16(user_selection) == 2)
            {
                printReport1(); 
                Console.Clear();
                printReport2(); 
                Console.Clear();
                printReport3();
                Console.WriteLine(); 
                Console.ResetColor();
            }
        }

        public static void printReport1()
        {
           // string[] airport_name = new string[4];// { "John F. Kenedy", "Pearson International", "Heathrow" };
            //string[] airport_city = new string[4];
           // double[] arrival_RunWay_Charges = new double[4];
            //double[] departure_RunWay_Charges = new double[4];
            //string[] activity_date = new string[4];
           // int[] total_passengers = new int[4];
            // double[] revenue_thatday = new double[4];
            int highest_flights = 200;
            int highest_passengers = 4500;
           double total_revenue = 870000;
           string airport_name = "John F. Kennedy";
           string airport_city = "New York";
           double arrival_RunWay_Charges =1001;
           double departure_RunWay_Charges = 1200;
           string [] activity_date = {"May-05-2015", "May-06-2015", "May-07-2015"};
           int [] numberof_flights = {300, 200, 100};
          int[] total_passengers = {1400,3000,4500};
          double [] revenue_thatday = {200000, 270000, 400000};
          Console.ForegroundColor = ConsoleColor.Magenta;
          Console.Write("Airport Name:       "); Console.WriteLine(airport_name);
          Console.Write("Aiport City:        "); Console.WriteLine(airport_city);
          Console.Write("Arrival Charges:    "); Console.WriteLine(arrival_RunWay_Charges);
          Console.Write("Departure Charges:  "); Console.WriteLine(departure_RunWay_Charges);
          Console.ResetColor();

          Console.WriteLine(); Console.WriteLine();
            
           for (int i = 0; i < total_passengers.Length ; i++)
           {
                Console.Write("Activity Date:      "); Console.WriteLine(activity_date[i]);
                Console.Write("Number of Flights:  "); Console.WriteLine(numberof_flights[i]);
                Console.Write("Total Passengers:   "); Console.WriteLine(total_passengers[i]);
                Console.Write("Revenue Generated:  "); Console.WriteLine(revenue_thatday[i]);
                Console.WriteLine(); 
            
             }
           Console.WriteLine("---------------------------------------------------------------");
           Console.WriteLine("Highest Flights: {0,-5:F0} Highest Passengers: {0,-5:F0}", highest_flights, highest_passengers);
           Console.WriteLine();
           Console.WriteLine("Revenue from Runway: {0,-5:C} Average Flights Served: {0,-5:F0}", total_revenue, 200);
           Console.WriteLine(); Console.ForegroundColor = ConsoleColor.Red; Console.WriteLine (" Press Any Key to see next Airport");
           Console.ReadKey(); Console.Clear();
         }

        public static void printReport2()
        {
            // string[] airport_name = new string[4];// { "John F. Kenedy", "Pearson International", "Heathrow" };
            //string[] airport_city = new string[4];
            // double[] arrival_RunWay_Charges = new double[4];
            //double[] departure_RunWay_Charges = new double[4];
            //string[] activity_date = new string[4];
            // int[] total_passengers = new int[4];
            // double[] revenue_thatday = new double[4];
            int highest_flights = 230;
            int highest_passengers = 4200;
            double total_revenue = 1100000;
            string airport_name = "Pearson International";
            string airport_city = "Toronto";
            double arrival_RunWay_Charges = 1600;
            double departure_RunWay_Charges = 1500;
            string[] activity_date = { "May-10-2015", "May-11-2015", "May-12-2015" };
            int[] numberof_flights = { 220, 230, 250 };
            int[] total_passengers = { 2500, 3300, 4200 };
            double[] revenue_thatday = { 250000, 350000, 500000 };
            Console.ResetColor(); Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write("Airport Name:       "); Console.WriteLine(airport_name);
            Console.Write("Aiport City:        "); Console.WriteLine(airport_city);
            Console.Write("Arrival Charges:    "); Console.WriteLine(arrival_RunWay_Charges);
            Console.Write("Departure Charges:  "); Console.WriteLine(departure_RunWay_Charges);
            Console.ResetColor();

            Console.WriteLine(); Console.WriteLine();

            for (int i = 0; i < total_passengers.Length; i++)
            {
                Console.Write("Activity Date:      "); Console.WriteLine(activity_date[i]);
                Console.Write("Number of Flights:  "); Console.WriteLine(numberof_flights[i]);
                Console.Write("Total Passengers:   "); Console.WriteLine(total_passengers[i]);
                Console.Write("Revenue Generated:  "); Console.WriteLine(revenue_thatday[i]);
                Console.WriteLine();

            }
            Console.WriteLine("---------------------------------------------------------------");
            Console.WriteLine("Highest Flights: {0,-5:F0} Highest Passengers: {0,-5:F0}", highest_flights, highest_passengers);
            Console.WriteLine();
            Console.WriteLine("Revenue from Runway: {0,-5:C} Average Flights Served: {0,-5:F0}", total_revenue, 233);
            Console.WriteLine(); Console.ForegroundColor = ConsoleColor.Red; Console.WriteLine(" Press Any Key to see next Airport");
            Console.ReadKey(); Console.Clear();
           
        }
        public static void printReport3()
        {
            // string[] airport_name = new string[4];// { "John F. Kenedy", "Pearson International", "Heathrow" };
            //string[] airport_city = new string[4];
            // double[] arrival_RunWay_Charges = new double[4];
            //double[] departure_RunWay_Charges = new double[4];
            //string[] activity_date = new string[4];
            // int[] total_passengers = new int[4];
            // double[] revenue_thatday = new double[4];
            int highest_flights = 440;
            int highest_passengers = 4500;
            double total_revenue = 2100000;
            string airport_name = "Heathrow";
            string airport_city = "London, UK";
            double arrival_RunWay_Charges = 1500;
            double departure_RunWay_Charges = 2000;
            string[] activity_date = { "Jun-01-2015", "Jun-02-2015", "May-03-2015" };
            int[] numberof_flights = { 300, 400, 440 };
            int[] total_passengers = { 5400, 6000, 7500 };
            double[] revenue_thatday = { 500000, 700000, 900000 };
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.Write("Airport Name:       "); Console.WriteLine(airport_name);
            Console.Write("Aiport City:        "); Console.WriteLine(airport_city);
            Console.Write("Arrival Charges:    "); Console.WriteLine(arrival_RunWay_Charges);
            Console.Write("Departure Charges:  "); Console.WriteLine(departure_RunWay_Charges);
            Console.ResetColor();

            Console.WriteLine(); Console.WriteLine();

            for (int i = 0; i < total_passengers.Length; i++)
            {
                Console.Write("Activity Date:      "); Console.WriteLine(activity_date[i]);
                Console.Write("Number of Flights:  "); Console.WriteLine(numberof_flights[i]);
                Console.Write("Total Passengers:   "); Console.WriteLine(total_passengers[i]);
                Console.Write("Revenue Generated:  "); Console.WriteLine(revenue_thatday[i]);
                Console.WriteLine();

            }
            Console.WriteLine("---------------------------------------------------------------");
            Console.WriteLine("Highest Flights: {0,-5:F0} Highest Passengers: {0,-5:F0}", highest_flights, highest_passengers);
            Console.WriteLine();
            Console.WriteLine("Revenue from Runway: {0,-5:C} Average Flights Served: {0,-5:F0}", total_revenue, 440);
            Console.WriteLine(); Console.ForegroundColor = ConsoleColor.Red; Console.WriteLine(" Press Any Key to Exit");
            Console.ReadKey();
        }

    }
        }




    