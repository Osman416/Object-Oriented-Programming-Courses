﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace MoviesApp
{
    public partial class Form1 : Form
    {
        private OleDbConnection connection = new OleDbConnection();
        
        public Form1()
        {
            InitializeComponent();
            connection.ConnectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\Osman\Documents\Semester 3\COMP2129 - ADV OBJECT-ORIENT.PROGRAMMING\assignment\MoviesDatabase.accdb;
Persist Security Info=False;";
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            try {
                
                connection.Open();
                lblTitle.Text = "Connected Successfully";
                connection.Close();
            }catch(Exception ex)
            {
                MessageBox.Show("Error :" + ex);
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {
            connection.Open();
            OleDbCommand command = new OleDbCommand() ;
            command.Connection = connection;
            string query = "SELECT * FROM `movie` WHERE `ID` = 1";
            //selc
            command.CommandText = query;
            OleDbDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                string title= reader["Title"].ToString();
                string genre = reader["Genre"].ToString();
                string realeaseDate = reader["ReleaseDate"].ToString();
                string sold = reader["Sold"].ToString();
                string description = reader["Description"].ToString();
                string path= reader["PicturePath"].ToString();
                lblTitle.Text = title;
                lblgenre.Text = genre;
                lblrelease.Text = realeaseDate ;
                richTextBox1.Text = description;
                pictureBox1.ImageLocation = "file:///C:/Users/Osman/Documents/Semester%203/COMP2129%20-%20ADV%20OBJECT-ORIENT.PROGRAMMING/Adv.OOP-LT4/JurassicParkPic.bmp"; 
                lblSold.Text = sold;


            }
            connection.Close();
        }

        private void label2_Click(object sender, EventArgs e) 
        {
            connection.Open();
            OleDbCommand command = new OleDbCommand();
            command.Connection = connection;
            string query = "SELECT * FROM `movie` WHERE `ID` = 2";
            command.CommandText = query;
            OleDbDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                string title = reader["Title"].ToString();
                string genre = reader["Genre"].ToString();
                string realeaseDate = reader["ReleaseDate"].ToString();
                string sold = reader["Sold"].ToString();
                string description = reader["Description"].ToString();
                string path = reader["PicturePath"].ToString();
                lblTitle.Text = title;
                lblgenre.Text = genre;
                lblrelease.Text = realeaseDate;
                richTextBox1.Text = description;
              //  pictureBox1.ImageLocation = "C:/Users/Osman/Documents/Semester%203/COMP2129/assignment/movies/AvengersAgeofUltron.bmp";
                pictureBox1.ImageLocation = "file:///C:/Users/Osman/Documents/Semester%203/COMP2129%20-%20ADV%20OBJECT-ORIENT.PROGRAMMING/Adv.OOP-LT4/AvengersAgeofUltron.bmp";
                lblSold.Text = sold;


            }
            connection.Close();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            connection.Open();
            OleDbCommand command = new OleDbCommand();
            command.Connection = connection;
            string query = "SELECT * FROM `movie` WHERE `ID` = 3";
            command.CommandText = query;
            OleDbDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                string title = reader["Title"].ToString();
                string genre = reader["Genre"].ToString();
                string realeaseDate = reader["ReleaseDate"].ToString();
                string sold = reader["Sold"].ToString();
                string description = reader["Description"].ToString();
                string path = reader["PicturePath"].ToString();
                lblTitle.Text = title;
                lblgenre.Text = genre;
                lblrelease.Text = realeaseDate;
                richTextBox1.Text = description;
               // pictureBox1.ImageLocation = "C:/Users/Osman/Documents/Semester%203/COMP2129/assignment/movies/InsideOut.bmp";
                pictureBox1.ImageLocation = "file:///C:/Users/Osman/Documents/Semester%203/COMP2129%20-%20ADV%20OBJECT-ORIENT.PROGRAMMING/Adv.OOP-LT4/InsideOut.bmp";
                lblSold.Text = sold;


            }
            connection.Close();
        }

        private void label4_Click(object sender, EventArgs e)
        {
            connection.Open();
            OleDbCommand command = new OleDbCommand();
            command.Connection = connection;
            string query = "SELECT * FROM `movie` WHERE `ID` = 4";
            command.CommandText = query;
            OleDbDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                string title = reader["Title"].ToString();
                string genre = reader["Genre"].ToString();
                string realeaseDate = reader["ReleaseDate"].ToString();
                string sold = reader["Sold"].ToString();
                string description = reader["Description"].ToString();
                string path = reader["PicturePath"].ToString();
                lblTitle.Text = title;
                lblgenre.Text = genre;
                lblrelease.Text = realeaseDate;
                richTextBox1.Text = description;
                //pictureBox1.ImageLocation = "C:/Users/Osman/Documents/Semester%203/COMP2129/assignment/movies/Furious7.bmp";
                pictureBox1.ImageLocation = "file:///C:/Users/Osman/Documents/Semester%203/COMP2129%20-%20ADV%20OBJECT-ORIENT.PROGRAMMING/Adv.OOP-LT4/fast_furious7.bmp";
                lblSold.Text = sold;


            }
            connection.Close();
        }
        
        private void label5_Click(object sender, EventArgs e)
        {
            connection.Open();
            OleDbCommand command = new OleDbCommand();
            command.Connection = connection;
            string query = "SELECT * FROM `movie` WHERE `ID` = 5";
            command.CommandText = query;
            OleDbDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                string title = reader["Title"].ToString();
                string genre = reader["Genre"].ToString();
                string realeaseDate = reader["ReleaseDate"].ToString();
                string sold = reader["Sold"].ToString();
                string description = reader["Description"].ToString();
                string path = reader["PicturePath"].ToString();
                lblTitle.Text = title;
                lblgenre.Text = genre;
                lblrelease.Text = realeaseDate;
                richTextBox1.Text = description;
               // pictureBox1.ImageLocation= "C:/Users/Osman/Documents/Semester%203/COMP2129/assignment/movies/Minions.bmp";
                pictureBox1.ImageLocation = "file:///C:/Users/Osman/Documents/Semester%203/COMP2129%20-%20ADV%20OBJECT-ORIENT.PROGRAMMING/Adv.OOP-LT4/Minions.bmp";
                lblSold.Text = sold;


            }
            connection.Close();
        }

        private void label6_Click(object sender, EventArgs e)
        {
            connection.Open();
            OleDbCommand command = new OleDbCommand();
            command.Connection = connection;
            string query = "SELECT * FROM `movie` WHERE `ID` = 6";
            command.CommandText = query;
            OleDbDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                string title = reader["Title"].ToString();
                string genre = reader["Genre"].ToString();
                string realeaseDate = reader["ReleaseDate"].ToString();
                string sold = reader["Sold"].ToString();
                string description = reader["Description"].ToString();
                string path = reader["PicturePath"].ToString();
                lblTitle.Text = title;
                lblgenre.Text = genre;
                lblrelease.Text = realeaseDate;
                richTextBox1.Text = description;
                //pictureBox1.ImageLocation = "C:/Users/Osman/Documents/Semester%203/COMP2129/assignment/movies/Martian.bmp";
                pictureBox1.ImageLocation = "file:///C:/Users/Osman/Documents/Semester%203/COMP2129%20-%20ADV%20OBJECT-ORIENT.PROGRAMMING/Adv.OOP-LT4/Martian.bmp";
                lblSold.Text = sold;


            }
            connection.Close();
        }

        private void label7_Click(object sender, EventArgs e)
        {
            connection.Open();
            OleDbCommand command = new OleDbCommand();
            command.Connection = connection;
            string query = "SELECT * FROM `movie` WHERE `ID` = 7";
            command.CommandText = query;
            OleDbDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                string title = reader["Title"].ToString();
                string genre = reader["Genre"].ToString();
                string realeaseDate = reader["ReleaseDate"].ToString();
                string sold = reader["Sold"].ToString();
                string description = reader["Description"].ToString();
                string path = reader["PicturePath"].ToString();
                lblTitle.Text = title;
                lblgenre.Text = genre;
                lblrelease.Text = realeaseDate;
                richTextBox1.Text = description;
                //pictureBox1.ImageLocation = "C:/Users/Osman/Documents/Semester%203/COMP2129/assignment/movies/.bmp";
                pictureBox1.ImageLocation = "file:///C:/Users/Osman/Documents/Semester%203/COMP2129%20-%20ADV%20OBJECT-ORIENT.PROGRAMMING/Adv.OOP-LT4/";
                lblSold.Text = sold;


            }
            connection.Close();
        }

        private void tabPage2_Click(object sender, EventArgs e)
        {
            
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            try
            {
                connection.Open();
                OleDbCommand command = new OleDbCommand();
                command.Connection = connection;
                string query = "INSERT INTO Movie (Title, Genre, ReleaseDate, Sold, Description, PicturePath) values('" + txt_title.Text + "', '" + txt_genre.Text + "', '" + txt_release.Text + "', '" + txt_sold.Text + "', '" + txt_descrip.Text + "', '" + txt_picpath.Text + "')";
                //string query = "INSERT INTO Movie (Title, Genre, ReleaseDate, Sold, Description, PicturePath) values('" + txt_title.Text + "', '" + txt_genre.Text + "', '" + txt_release.Text + "', '" + txt_sold.Text + "', '" + txt_descrip.Text + "', '" + txt_picpath.Text + "')";
                //string query = "INSERT INTO Movie FROM Title = '" + txt_title.Text + "', Genre = '" + txt_genre.Text + "', ReleaseDate = '" + txt_release.Text + "', Sold = '" + txt_sold.Text + "', Description = '" + txt_descrip.Text + "', PicturePath = '" + txt_picpath.Text + "' WHERE ID = " + txt_id.Text + "";
                MessageBox.Show(query);
                command.CommandText = query;

                command.ExecuteNonQuery();
                MessageBox.Show("data is added");
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error " + ex);
            }

        }

        private void btn_edit_Click(object sender, EventArgs e)
        {
            try
            {
                connection.Open();
                OleDbCommand command = new OleDbCommand();
                command.Connection = connection;
                string query = "UPDATE Movie SET Title = '" + txt_title.Text + "', Genre = '" + txt_genre.Text + "', ReleaseDate = '" + txt_release.Text + "', Sold = '" + txt_sold.Text + "', Description = '" + txt_descrip.Text + "', PicturePath = '" + txt_picpath.Text + "' WHERE ID = " + txt_id.Text + "";
                MessageBox.Show(query);
                command.CommandText = query;

                command.ExecuteNonQuery();
                MessageBox.Show("data edit sucessful");
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error " + ex);
            }
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            try
            {
                connection.Open();
                OleDbCommand command = new OleDbCommand();
                command.Connection = connection;
                string query = "DELETE FROM Movie WHERE ID =" + txt_id.Text + "";
                MessageBox.Show(query);
                command.CommandText = query;

                command.ExecuteNonQuery();
                MessageBox.Show("data is deleted");
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error " + ex);
            }

        }

        private void txt_search_TextChanged(object sender, EventArgs e)
        {
            connection.Open();
            OleDbCommand command = new OleDbCommand();
            command.Connection = connection;
            string query = "SELECT * FROM Movie WHERE Title LIKE '%"+txt_search.Text.ToString()+"%'";
            //selc
            command.CommandText = query;
            OleDbDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                string title = reader["Title"].ToString();
                string genre = reader["Genre"].ToString();
                string realeaseDate = reader["ReleaseDate"].ToString();
                string sold = reader["Sold"].ToString();
                string description = reader["Description"].ToString();
                string path = reader["PicturePath"].ToString();
                lblTitle.Text = title;
                lblgenre.Text = genre;
                lblrelease.Text = realeaseDate;
                richTextBox1.Text = description;
                pictureBox1.ImageLocation = "file:///C:/Users/Osman/Documents/Semester%203/COMP2129%20-%20ADV%20OBJECT-ORIENT.PROGRAMMING/Adv.OOP-LT4/JurassicParkPic.bmp";
                lblSold.Text = sold;


            }
            connection.Close();
        }

    }
}
